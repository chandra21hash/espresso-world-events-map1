import React, { useEffect, useMemo, useState } from "react";
import { MapContainer, TileLayer, CircleMarker, Popup, Rectangle, useMap } from "react-leaflet";
import MarkerClusterGroup from "react-leaflet-cluster";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import eventsData from "../data/espresso-events.json";

const DARK_ESPRESSO = "#b36d3c";
const LIGHT_ESPRESSO = "#f2b98f";
const MARKER_RADIUS = 9;

function FitBoundsToEvents({ bounds }) {
  const map = useMap();
  useEffect(() => { if (bounds?.length) map.fitBounds(bounds, { padding:[40,40], maxZoom:5 }); }, [bounds, map]);
  return null;
}

function createClusterCustomIcon(cluster, mode) {
  const count = cluster.getChildCount();
  const color = mode === "past" ? DARK_ESPRESSO : LIGHT_ESPRESSO;
  return L.divIcon({
    html: `<div style="background:${color};color:#fff;border-radius:50%;width:40px;height:40px;display:flex;align-items:center;justify-content:center;font-weight:bold;">${count}</div>`,
    className: "custom-cluster", iconSize:[40,40]
  });
}

export default function EspressoWorldMapToggle() {
  const [mode,setMode]=useState("past");
  const events = mode==="past"?eventsData.pastEvents:eventsData.upcomingEvents;
  const bounds = useMemo(()=>[...(eventsData.pastEvents),...(eventsData.upcomingEvents)].map(e=>e.coords),[]);
  return (
    <div style={{maxWidth:1100,margin:"18px auto"}}>
      <MapContainer center={[20,0]} zoom={2} style={{height:560,width:"100%"}}>
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"/>
        <FitBoundsToEvents bounds={bounds}/>
        <MarkerClusterGroup iconCreateFunction={(cl)=>createClusterCustomIcon(cl,mode)}>
          {events.map((ev,idx)=>(
            <CircleMarker key={idx} center={ev.coords} radius={MARKER_RADIUS}
              pathOptions={mode==="past"?{fillColor:DARK_ESPRESSO,color:"white",fillOpacity:1}:{fillColor:"white",color:DARK_ESPRESSO,fillOpacity:1}}>
              <Popup><div><b>{ev.event}</b><br/>{ev.city}, {ev.country}<br/>Date: {ev.date}<br/>Status: {ev.status}<br/><a href={ev.link} target="_blank">View Event</a></div></Popup>
            </CircleMarker>
          ))}
        </MarkerClusterGroup>
      </MapContainer>
    </div>
  );
}